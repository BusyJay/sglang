# Qwen3.8 MTP W4A4 独立候选 patch

基线：`581b2fa446eab9b1ae341492adc1bc4aff24d281`。此候选直接基于当前基线；不重放旧 00–12 系列。
包内不含镜像或权重，沿用现有服务镜像和 FP4-Local checkpoint。

```bash
# 在解包目录检查文件完整性。
sha256sum -c SHA256SUMS
# 在基线源码 checkout 中执行，DELIVERY 为解包目录的绝对路径。
git apply --check "$DELIVERY/01-mtp-w4a4.patch"
git apply "$DELIVERY/01-mtp-w4a4.patch"
# 删除候选时：
git apply -R --check "$DELIVERY/01-mtp-w4a4.patch"
git apply -R "$DELIVERY/01-mtp-w4a4.patch"
```

模型 worker 环境变量 `SGLANG_QWEN38_MTP_ACTIVATION=w4a4` 启用候选；
`w4a16` 回滚，需要重启 worker。未设置时仍为 W4A16，等待用户 macro bench
验收后再决定默认切换。target decode/verify 精度不受此开关控制。

292 项镜像 CPU 回归及真实依赖导入检查通过。GPU/宏基准/质量未运行。
详见 MTP_W4A4.md 的 GPU 单测、端到端测试、额外显存和适用范围。
manifest.json 记录基线/tree/hash，validation.json 记录验收状态。
